import { SecondLetterCapitalPipe } from './second-letter-capital.pipe';

describe('SecondLetterCapitalPipe', () => {
  it('create an instance', () => {
    const pipe = new SecondLetterCapitalPipe();
    expect(pipe).toBeTruthy();
  });
});
